import {createSlice} from "@reduxjs/toolkit";
import { items } from "../data/items";

const itemSlice = createSlice({
    name: 'item',
    initialState: items,
    reducers: {
        addInitialItems: (state, action) => {
              return state;
        }
    }
})
export const itemsActions = itemSlice.actions

export default itemSlice